const leaderboard = ['Harry', 'Lua', 'Hermoine', 'Bellatrix']; //DON'T TOUCH THIS LINE!

// YOUR CODE BELOW HERE: