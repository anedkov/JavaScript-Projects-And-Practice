const leaderboard = ['Harry', 'Lua', 'Hermoine', 'Bellatrix'];
leaderboard[1] = "Luna";
leaderboard[3] = "Draco";