const bestColor = "purple";
const quote = 'You had me at "hello"';