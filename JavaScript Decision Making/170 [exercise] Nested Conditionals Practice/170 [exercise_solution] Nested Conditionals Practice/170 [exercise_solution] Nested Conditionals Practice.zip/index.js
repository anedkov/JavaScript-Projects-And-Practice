// Change the value of num, so that "YOU GOT ME!" prints out
const num = 102;

// DO NOT TOUCH! (please)
if(num <= 100) {
    if(num >= 50) {
        console.log("HEY!");
    }
} else {
    if (num < 103) {
        if(num % 2 === 0){
            console.log("YOU GOT ME!");
        }
    }
}