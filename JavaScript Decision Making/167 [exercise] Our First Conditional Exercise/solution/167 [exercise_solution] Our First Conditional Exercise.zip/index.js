function isEven(num){
    //WRITE YOUR CODE BETWEEN THIS LINE:
    if(num % 2 === 0){
        console.log("even");
    }
    //AND THIS LINE
}