let myLuckyNumber = 37;
let octopusLimbs = 8;