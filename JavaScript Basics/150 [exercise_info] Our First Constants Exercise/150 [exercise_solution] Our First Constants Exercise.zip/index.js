const boilingPointC = 100;
const boilingPointF = 212;