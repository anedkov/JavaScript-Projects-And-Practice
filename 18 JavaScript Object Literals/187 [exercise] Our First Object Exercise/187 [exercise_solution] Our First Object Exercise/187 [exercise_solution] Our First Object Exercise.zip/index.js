const product = {
    name: 'Gummy Bears',
    inStock: true,
    price: 1.99,
    flavors: ['cherry', 'orange', 'lemon']
}